package com.shield

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** Права администратора нужны только для одного: пока они включены, приложение нельзя удалить. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Щит от 18+ не даст отключить себя без пароля. Подумай ещё раз, ты сам это выбрал."

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Guard.init(context)
        // права сняли, пока защита заперта и окно не открыто: запоминаем
        if (Guard.protectOn() && Guard.locked()) Guard.markTamper()
    }
}
